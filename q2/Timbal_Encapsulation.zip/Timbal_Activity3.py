
# Activity 3: BankAccount Class
# Applying Encapsulation

class BankAccount:
    def __init__(self, account_number, balance):
        self.__account_number = ""
        self.__balance = 0.0

        self.set_account_number(account_number)
        self.set_balance(balance)

    # setter for account number
    def set_account_number(self, account_number):
        self.__account_number = account_number

    # getter for account number
    @property
    def account_number(self):
        return self.__account_number

    # setter for balance
    def set_balance(self, balance):
        if balance >= 0:
            self.__balance = balance
        else:
            print("Warning: Balance cannot be negative.")

    # getter for balance
    @property
    def balance(self):
        return self.__balance


# create a BankAccount object
account = BankAccount("1234567890", 5000)

# display the account information
print("Account Number:", account.account_number)
print(f"Balance: ₱{account.balance:.2f}")

# update the account number
account.set_account_number("9876543210")

# update the balance
account.set_balance(7500)

# display the updated information
print("\nUpdated Account Information:")
print("Account Number:", account.account_number)
print(f"Balance: ₱{account.balance:.2f}")

# Test the balance validation
account.set_balance(-1000)

# display the balance after the invalid update
print(f"Final Balance: ₱{account.balance:.2f}")

#hi sir 