# My Chinese Zodiac Program :)

## Requirements given:
1. Ask the user to enter a year of birth (Baseline year: 1900).
2. Validate that the input year is not earlier than 1900.
3. If invalid, display an error message and stop.
4. Determine the Chinese Zodiac sign based on a 12-year cycle starting from 1900.
5. Consider only the year of birth.

## code!!

zodiacs = [

    "Rat (鼠 / Shǔ)",
    "Ox (牛 / Niú)",
    "Tiger (虎 / Hǔ)",
    "Rabbit (兔 / Tù)",
    "Dragon (龙 / Lóng)",
    "Snake (蛇 / Shé)",
    "Horse (马 / Mǎ)",
    "Goat (羊 / Yáng)",
    "Monkey (猴 / Hóu)",
    "Rooster (鸡 / Jī)",
    "Dog (狗 / Gǒu)",
    "Pig (猪 / Zhū)"
]

year = int(input("Enter your birth year: "))

if year < 1900:

    print("Invalid year, it should not be earlier than 1900 :P")
else:

    index = (year - 1900) % 12
    print("Your Chinese Zodiac Sign is :", zodiacs[index], "! :)")


## Documented/Screenshot of success:

![Output screenshot](screenshot.png)
